How to run

1) Change directory to code
2) Run myDriver()

Elapsed time is 14.249445 seconds.